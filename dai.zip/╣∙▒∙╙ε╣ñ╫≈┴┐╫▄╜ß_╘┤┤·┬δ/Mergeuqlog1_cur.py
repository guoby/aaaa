#encoding=utf-8
import pymongo
import time
import logging
import logging.config
import logging.handlers
import datetime
from xmlrpclib import DateTime

# 增量数据库信息
RAW_IP = "localhost"
RAW_PORT = 27017
RAW_DATABASENAME = "faq_raw_data"
RAW_TABLENAME = "mark"

# 数据保存到的数据库信息
TARGET_IP = "localhost"
TARGET_PORT = 27017
TARGET_DATABASENAME = "faq_handle_data"
TARGET_TABLENAME = "uqestion_merge"
TARGET_TABLENAME_CHANNEL = "uqestion_channel"
TARGET_USER = "qa"
TARGET_PWD = "qa321"


DATA_TYPE = 1


LOG_FILE = 'e:\\python\\faq.log'  
handler = logging.handlers.RotatingFileHandler(LOG_FILE, maxBytes = 1024*1024, backupCount = 5) # 实例化handler   
fmt = '%(asctime)s - %(filename)s:%(lineno)s - %(levelname)s - %(message)s'  
   
formatter = logging.Formatter(fmt)   # 实例化formatter  
handler.setFormatter(formatter)      # 为handler添加formatter  
   
logger = logging.getLogger('tst')    # 获取名为tst的logger  
logger.addHandler(handler)           # 为logger添加handler  
logger.setLevel(logging.DEBUG)  


def getRawData():
    conn = pymongo.MongoClient(RAW_IP, RAW_PORT)
    db = conn[RAW_DATABASENAME]
    rawTable = db[RAW_TABLENAME]
    curTime = time.strftime("%Y%m%d",time.localtime(time.time()))
    
    resultList = []
    for item in rawTable.find({"province":{"$ne":"全国"},"mSquestion":{"$nin":['null','']},"uquestion":{"$nin":['null','']},"mType":{"$in":[0,'0']},"mTime":{"$in":[curTime]}}):
        resultList.append(item)
    
    return resultList


def handleOneData(e):
    
    level = 0
    squestion = e['mSquestion']
    date_time = e['mTime']
    
    if e['province'].encode("utf-8") in "北京江苏":
        level = 1
    
    element = queryByWhereStr({"uquestion":e['uquestion'],"province":e['province'],"datatype":DATA_TYPE})
    if(len(element) > 0):
        
        date_format = "%Y%m%d"
        date_time1 = time.strptime(date_time, date_format)
        date_time2 = time.strptime(element[0]['date'], date_format)
        if time.mktime(date_time1) > time.mktime(date_time2):
            update(e['uquestion'], e['province'], DATA_TYPE, squestion, date_time, level)
        
    else:
        addElement = {}
        addElement.setdefault('province',e['province'])
        addElement.setdefault('uquestion',e['uquestion'])
        addElement.setdefault('squestion',squestion)
        addElement.setdefault("date", date_time)
        addElement.setdefault("level", level)
        addElement.setdefault("keywords", "")
        addElement.setdefault('channel',e['channel'])
        channel = queryChannelByWhereStr({"province":e['province']})
        if(len(channel) > 0):
            addElement.setdefault('province_code',channel[0]['provinceId'])
            insert(addElement)


def handleDate(resList):

    for item in resList:
        try:
            if type(item['mSquestion']) == type(None) or type(item['uquestion']) == type(None):
                print "value is null"
                logger.error("value is null")
                continue
            
            handleOneData(item)
        except Exception, e:  
            logger.error("Exception,:" + str(e))
            print Exception,":",e

def queryByWhereStr(whereStr):
    resultList = []
    conn = pymongo.MongoClient(TARGET_IP, TARGET_PORT)
    db = conn[TARGET_DATABASENAME]
    db.authenticate(TARGET_USER, TARGET_PWD)
    for i in db[TARGET_TABLENAME].find(whereStr):
        resultList.append(i)
    
    return resultList

def queryChannelByWhereStr(whereStr):
    resultList = []
    conn = pymongo.MongoClient(TARGET_IP, TARGET_PORT)
    db = conn[TARGET_DATABASENAME]
    db.authenticate(TARGET_USER, TARGET_PWD)
    for i in db[TARGET_TABLENAME_CHANNEL].find(whereStr):
        resultList.append(i)
    
    return resultList

def insert(element):
    conn = pymongo.MongoClient(TARGET_IP, TARGET_PORT)
    db = conn[TARGET_DATABASENAME]
    db.authenticate(TARGET_USER, TARGET_PWD)
    curTime = time.strftime("%Y%m%d",time.localtime(time.time()))
    
    e = {}
    e.setdefault("province", element['province'])
    e.setdefault("uquestion", element['uquestion'])
    e.setdefault("squestion", element['squestion'])
    e.setdefault("channel", element['channel'])
    e.setdefault("province_code", element['province_code'])
    e.setdefault("date", element['date'])
    e.setdefault("level", element['level'])
    e.setdefault("keywords", element['keywords'])
    e.setdefault("datatype", DATA_TYPE)
    #向集合t_handle 添加数据
    db[TARGET_TABLENAME].insert_one(e)
    
    print "insert:-----squestion:" + element['squestion'] + "---------province:" + element['province']
    logger.info("insert:-----squestion:" + element['squestion'] + "---------province:" + element['province'])
    
    
def update(uquestion, province, data_type, squestion, date_time, level):
    conn = pymongo.MongoClient(TARGET_IP, TARGET_PORT)
    db = conn[TARGET_DATABASENAME]
    db.authenticate(TARGET_USER, TARGET_PWD)
    curTime = time.strftime("%Y%m%d",time.localtime(time.time()))
    db[TARGET_TABLENAME].update_one({'uquestion':uquestion,'province':province,"datatype":data_type}, {'$set':{'squestion':squestion,"date":date_time,"level":level}})
    
    print "update:-----squestion:" + squestion + "---------province:" +province
    logger.info("update:-----squestion:" + squestion + "---------province:" +province)

def main():
    resultList = getRawData()
    if len(resultList) == 0:
        print "没有数据"
    else:
        handleDate(resultList)
    
    
if __name__=="__main__":
    main()