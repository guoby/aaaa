package com.cmri.kb.thread;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.poi.POIXMLDocument;
import org.apache.poi.POIXMLTextExtractor;
import org.apache.poi.hwpf.extractor.WordExtractor;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.xwpf.extractor.XWPFWordExtractor;
import org.springframework.context.support.GenericXmlApplicationContext;

import com.cmri.kb.core.DataAccessException;
import com.cmri.kb.dao.content.ContentDao;
import com.cmri.kb.dao.content.impl.ContentDaoImpl;
import com.cmri.kb.dao.noderelation.NodeRelationDao;
import com.cmri.kb.dao.noderelation.impl.NodeRelationDaoImpl;
import com.cmri.kb.dao.template.TemplateDao;
import com.cmri.kb.dao.template.impl.TemplateDaoImpl;
import com.cmri.kb.domain.Content;
import com.cmri.kb.domain.FileInfo;
import com.cmri.kb.domain.KnowledgeNode;
import com.cmri.kb.service.node.NodeService;
import com.cmri.kb.service.node.impl.NodeServiceImpl;
import com.google.gson.Gson;

/***
 * 添加目录
 * 
 * @Title: AddNode.java
 * @Package com.cmri.kb.thread
 * @author guoby
 * @date 2016年11月18日
 */
public class AddNode {
	
	private Logger log = Logger.getLogger(AddNode.class);
	
	private NodeService nodeService;
	private NodeRelationDao nodeRelationDao;
	private TemplateDao templateDao;
	private ContentDao contentDao;
	
	private static String REST_PROP = "poi.properties";
	private static String fileUrl;
	// 保存world中的图片
	private static String imgPath;
	
	// 模板号
	private static int templateType=20;
	
	public AddNode(){
		Properties prop = new Properties();
		InputStream fis = null;
		fis = FaqfromExcel.class.getResourceAsStream("/" + REST_PROP);
		
		try {
			prop.load(fis);
			fileUrl = prop.getProperty("temp_node_file_url");
			imgPath = prop.getProperty("temp_save_img_url");
			
			GenericXmlApplicationContext context = new GenericXmlApplicationContext();
			context.setValidating(false);
//			applicationContext*.xml  testContext*.xml
			context.load("classpath*:applicationContext*.xml");
			context.refresh();
			templateDao = context.getBean(TemplateDaoImpl.class); 
			nodeService = context.getBean(NodeServiceImpl.class); 
			nodeRelationDao = context.getBean(NodeRelationDaoImpl.class);
			contentDao = context.getBean(ContentDaoImpl.class);
			
		} catch (Exception e) {
			log.error("构造方法出错：", e);
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		
		AddNode addnode = new AddNode();
		
		// 添加模板
		addnode.addNewTemplate(templateType);

		// 读取文件
		List<FileInfo> fileList = addnode.readFileMsg(fileUrl);
		// 添加节点
		addnode.saveNode("root", fileList);
		
	}
	
	private List<FileInfo> readFileMsg(String filePath) {
		List<FileInfo> resultList = new ArrayList<FileInfo>();

		File file = new File(filePath);
		File[] tempList = file.listFiles();

		for (File f : tempList) {
			FileInfo fileInfo = new FileInfo();

			if (f.isFile()) {
				// System.out.println("文件：" + f.getName());
				String nodeName = f.getName().substring(0, f.getName().lastIndexOf("."));
				fileInfo.setFileName(nodeName);
				fileInfo.setCategory(KnowledgeNode.NODE_CATEGORY_LEAF);
				
				//添加节点内容
				String fpath = filePath + File.separator + f.getName();
				String worldContent = "";
//				String worldContent = readWorld(fpath);
				worldContent = ReadWorldContentAndStyle.readWorldAndStyle(fpath, imgPath);
				if(worldContent.length() > 0)
					saveKnowledgeContent(nodeName, worldContent.trim());
			}

			if (f.isDirectory()) {
				// System.out.println("文件夹：" + f.getName());
				fileInfo.setFileName(f.getName());
				fileInfo.setCategory(KnowledgeNode.NODE_CATEGORY_BRANCH);

				String path = filePath + File.separator + f.getName();
				fileInfo.setChildFileList(readFileMsg(path));
			}
			resultList.add(fileInfo);
		}

		return resultList;

	}
	
	/***
	 * 添加节点、已经节点所对应的内容
	 * @param nodeName 父节点
	 * @param fileList 需要添加的节点集合
	 */
	private void saveNode(String nodeName, List<FileInfo> fileList) {

		try {
			for (int i = 0; i < fileList.size(); i++) {
				FileInfo file = fileList.get(i);
				String subNodeName = file.getFileName();
				int category = file.getCategory();
				List<FileInfo> childFileList = file.getChildFileList();

				if (nodeRelationDao.getNodeIdByName(subNodeName) != -1) {
					log.info("[" + subNodeName + "]已经存在！");
					continue;
				}
				nodeService.addNode(nodeName, subNodeName, category);
				// 添加子节点
				if(category == KnowledgeNode.NODE_CATEGORY_BRANCH && childFileList != null)
					saveNode(subNodeName, childFileList);
				
				// 设置节点对应的模板
				setNodeTemplate(subNodeName, templateType);
			}
		} catch (Exception e) {
			log.error("添加节点出错：", e);
			e.printStackTrace();
		}

	}
	
	/***
	 * 创建新模板
	 * 
	 * @param templateType 模板编号
	 */
	private void addNewTemplate(int templateType){
		Content root = new Content("", "");
		//业务介绍
		Content first1 = new Content("介绍", "");
		first1.add(new Content("内容", ""));
		root.add(first1);
		
		Gson gson = new Gson();
		String structure = gson.toJson(root);
		try {
			String res = templateDao.getTemplateByType(templateType);
			if(res.length() > 0){
				log.info("【" + templateType + "号模板】，已经存在！");
				return;
			}
			templateDao.addTemplate(templateType, structure);
		} catch (DataAccessException e) {
			log.error("添加模板失败：", e);
			e.printStackTrace();
		}
		
	}
	
	/***
	 * 读取world 文档
	 * 
	 * @param path 文件路径
	 * @return
	 */
	private String readWorld(String path) {
		InputStream is = null;
		String content = "";
		String suffix = path.substring(path.lastIndexOf(".") + 1);
		try {
			if (suffix.equals("doc")) {
				// word 2003： 图片不会被读取
				 is = new FileInputStream(new File(path));
				 WordExtractor ex = new WordExtractor(is);
				// is是WORD文件的InputStream
				 content = ex.getText().trim();
			} else if (suffix.equals("docx")) {
				// word 2007 图片不会被读取， 表格中的数据会被放在字符串的最后
				OPCPackage opcPackage = POIXMLDocument.openPackage(path);
				POIXMLTextExtractor extractor = new XWPFWordExtractor(opcPackage);
				content = extractor.getText().trim();
				content = content.replaceAll("\n", "<br/>");
				System.out.println(content);
			}
		} catch (Exception e) {
			log.error("读取world文件出错：", e);
			e.printStackTrace();
		} finally {
			if (is != null) {
				try {
					is.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return content;

	}
	
	private void saveKnowledgeContent(String nodeName, String content){
		
		try {
			contentDao.updateEleContent(nodeName, true, "", "", "web", "介绍_内容", content);
		} catch (DataAccessException e) {
			log.error(nodeName + "，添加节点内容失败：", e);
			e.printStackTrace();
		}
		
	}
	
	private void setNodeTemplate(String subNodeName,int templateType){
		try {
			int nodeId = nodeRelationDao.getNodeIdByName(subNodeName);
			int result = nodeRelationDao.checkexistsTemplateNode(nodeId);
			if(result == 0){
				nodeService.setNodeTemplate(subNodeName, templateType);
			}else{
				log.info(subNodeName + "节点，已经设置了模板。");
			}
		} catch (DataAccessException e) {
			log.error("设置节点模板失败：", e);
			e.printStackTrace();
		}
	}
	
	
    
}
