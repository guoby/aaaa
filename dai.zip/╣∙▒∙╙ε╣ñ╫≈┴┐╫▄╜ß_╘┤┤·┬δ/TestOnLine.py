# -*- coding: utf-8 -*-
"""
推荐准确率，在线测试
2017-08-17
"""
import json

import logging
import logging.handlers
import pymongo
import time

MONGO_IP = "localhost"
MONGO_PORT = 27017
MONGO_DATABASENAME = "faq_handle_data"
MONGO_TABLENAME = "uqestion_merge"

LOG_FILE = 'E:\\tmp\\python\\faq.log'
handler = logging.handlers.RotatingFileHandler(LOG_FILE, maxBytes=1024 * 1024, backupCount=5)  # 实例化handler
fmt = '%(asctime)s - %(filename)s:%(lineno)s - %(levelname)s - %(message)s'

formatter = logging.Formatter(fmt)  # 实例化formatter
handler.setFormatter(formatter)  # 为handler添加formatter

logger = logging.getLogger('tst')  # 获取名为tst的logger
logger.addHandler(handler)  # 为logger添加handler
logger.setLevel(logging.DEBUG)


class TestOnLine:

    def __init__(self):
        self.mongo_ip = MONGO_IP
        self.mongo_port = MONGO_PORT
        self.mongo_database = MONGO_DATABASENAME
        self.mongo_tablename = MONGO_TABLENAME
        # creat conn
        self.conn = pymongo.MongoClient(MONGO_IP, MONGO_PORT)
        self.db = self.conn[MONGO_DATABASENAME]

    #取标准问题
    def qurryAllsquestion(self):
        allSquestion = self.db.uqestion_merge.distinct("squestion", {})
        str_len = "qurry all Squestion data of number: ",len(allSquestion)
        print str_len
        logger.info(str_len)
        # close
        self.closeMongoDB()
        return allSquestion

    def closeMongoDB(self):
        # close
        self.conn.close()

    def readSourceDataFormTxt(self, txtPath):

        mList = [] #每个人推荐数占比都放在list
        allSquestionList = self.qurryAllsquestion()
        u = 0 #点了推荐的人数
        un = 0 #日志中总人数

        m = 0 #问题序列是推荐给出的个数
        mn = 0 #在推荐人范围内，排除第一个问题的问题总数

        readfiledata = open(txtPath, 'r')
        for lines in readfiledata.readlines():
            m0 = 0
            mn0 = 0

            vdict = json.loads(lines)
            userSquestionList = vdict.values()[0].keys()

            tempList = [ e for e in userSquestionList[1:] if e in allSquestionList]
            tempSize = len(tempList)
            if tempSize >= 1:
                u += 1
                m0 = tempSize
                mn0 = len(userSquestionList) - 1

                m += m0
                mn += mn0

                mList.append(m0*1.0/mn0)

            un += 1
            print un
            pass

        readfiledata.close()


        str_u = "u__U__u/U: ",u, un, u*1.0/un
        str_m = "m__M__m/M: ",m, mn, m*1.0/mn
        sum = 0.0
        for i in mList:
            sum += i
        str_avgM = "avg_m/M: ", sum, len(mList),sum/len(mList)

        print str_u
        print str_m
        print str_avgM

        logger.info(str_u)
        logger.info(str_m)
        logger.info(str_avgM)

    def readSourceFileData(self, sourceFilePath):

        allSquestionList = self.qurryAllsquestion()

        readfile = open(sourceFilePath, "r")
        count =0
        for lines in readfile.readlines():
            count += 1
            print type(lines)
            vdict = json.loads(lines)
            userSquestionList = vdict.values()[0].keys()
            tempList = [e for e in userSquestionList[1:] if e in allSquestionList]
            # a_list = userSquestionList[1:]
            # tempList = list((set(a_list).union(set(allSquestionList))) ^ (set(a_list) ^ set(allSquestionList)))
            print count,tempList

        readfile.close()
        pass


def filter29(readfilePath, writeFilePath):
    print '9 >= x >=2'
    print "---------- start 过滤 ----------"
    count = 0

    filedata = open(readfilePath, 'rb')
    try:
        wfile = open(writeFilePath, 'w')
        for line in filedata.readlines():
            jsonLine = json.loads(line)
            stqlist = jsonLine.values()[0].keys()
            if len(stqlist) < 2 or len(stqlist) > 9:
                continue
            count += 1
            writeStr = json.dumps(jsonLine, ensure_ascii=False).encode('utf-8') + '\n'
            wfile.write(writeStr)

        filedata.close()
        wfile.close()
        print "count = " + str(count)
    except IOError:
        print ("写入数据出错")
    print "---------- end 过滤 ----------"

def filter_changeDataDictType(readfilePath, writeFilePath):
    print "start run filter_changeDataDictType：dict change list dict，filter 2<= stq <=9... ..."

    filedata = open(readfilePath, 'rb')
    try:
        wfile = open(writeFilePath, 'w')
        context = json.loads(filedata.read())

        for item in  context.iteritems():
            eleDict = {}
            stqlist = item[1].keys()

            if(len(stqlist) >= 2 and len(stqlist) <= 9):
                eleDict.setdefault(item[0], item[1])
                writeStr = json.dumps(eleDict, ensure_ascii=False).encode('utf-8') + '\n'
                wfile.write(writeStr)

        filedata.close()
        wfile.close()
    except IOError:
        print ("转换数据格式出错......")
    print "---------- end 过滤 ----------"



if __name__ == '__main__':
    logger.info("... ... start run ... ...")
    start = time.time()
    inputFilePath = "temp_filecache_2_9.txt"

    """
    第一步：初始化，生成txt数据文件。若文件已经生成，可忽略
    """
    # src_file_path = 'E:\\guoby\\work\\1task\\task_20170424\\filecache0821.txt'
    # filter_changeDataDictType(src_file_path, inputFilePath)

    testLine = TestOnLine()
    """
    第二步：计算
    """
    testLine.readSourceDataFormTxt(inputFilePath)
    # testLine.readSourceFileData(inputFilePath)


    str_time = "time cost: ", time.time() - start
    print str_time
    logger.info(str_time)
    pass