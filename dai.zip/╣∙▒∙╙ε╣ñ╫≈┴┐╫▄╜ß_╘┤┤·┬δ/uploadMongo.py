# -*- coding=utf-8 -*-
import json
import pymongo
import sys,os,re
import datetime, time
import MongoConn

import logging
logging.basicConfig(filename='repeat_data2.log', level=logging.DEBUG)


today = datetime.date.today()
cur_date_str = today.strftime("%Y-%m-%d")
today = today + datetime.timedelta(days = -1)
today = today.strftime("%Y%m%d")



uq_count = dict()
'''
with open("./Data/qu_count"+str(today),"r") as f:
    for line in f:
        line = line.strip()
        if len(line.split('\t'))==2:
            uq_count[line.split('\t')[0]] = line.split('\t')[1]
'''


tablename = 'level3'


if __name__ == '__main__' :
    start = time.time()
    try:
        # conn = pymongo.MongoClient('198.168.39.99', 27017)
        # conn = pymongo.Connection('172.17.15.12', 27017)
        conn = pymongo.MongoClient('localhost', 27017)

        mydb = conn.level3

        # # querry mongo all data
        # querryAllDataResult = mydb[tablename].find({}, {"_id": 1})
        # querryAllDataResult_list = list(querryAllDataResult)
        # print len(querryAllDataResult_list)
        # print 'query all data cost time:', (time.time() - start)

        # mydb.authenticate("log","log321#@!")
        # f = open("/home/wangyanmeng/level3/L3_20160101_20170831.txt")
        f = open("E:\\guoby\\work\\1task\\task_20171225\\test20000")
        # f = open("test_1w.txt")

        resDict = {}
        for line in f:
            dic = {}

            items = line.rstrip().split('\t')
            dic['userQ'] = items[0]
            dic['stdQ'] = items[1]
            dic['province'] = items[2]
            dic['action'] = items[3]
            dic['B'] = items[4]
            dic['C'] = items[5]
            dic['D'] = items[6]
            dic['E'] = items[7]

            key_province_userQ = items[2] + '~' + items[0]
            dic['_id'] = key_province_userQ
            dic_str = json.dumps(dic, ensure_ascii=False)
            if len(items[0]) > 600:
                logging.warning("\t".join([cur_date_str, "L", key_province_userQ, dic_str]))
                continue

            if key_province_userQ not in resDict:
                resDict.setdefault(key_province_userQ, [])
            resDict.get(key_province_userQ).append(dic_str)

        print len(resDict.keys())
        print 'combination data cost time:', (time.time() - start)
        # print json.dumps(resDict.keys(), ensure_ascii=False)

        addManyList = []
        # insert mongo
        for k, values in resDict.items():
            values = set(values)
            values_count = len(values)
            try:
                if values_count > 1:  # logging
                    for dic_str in values:
                        logging.warning("\t".join([cur_date_str, "t", k, dic_str]))
                        # print 'logging.warning(... ....)'

                elif values_count == 1:  # insert
                    query_result = mydb[tablename].find({'_id': k}, {'_id': 1})
                    query_result_list = list(query_result)
                    query_result_count = len(query_result_list)

                    values = list(values)
                    if query_result_count == 0:  # insert
                        # print values[0]
                        dic = json.loads(values[0])
                        addManyList.append(dic)

                    else:  # logging
                        # print 'print log ... ...'
                        logging.warning("\t".join([cur_date_str, "m", k, values[0]]))

            except Exception, e:
                print e
                msg = e, k
                logging.error(msg)

        print 'add list cost time:', (time.time() - start)
        # insert many
        if len(addManyList) > 0:
            mydb[tablename].insert_many(addManyList)
        print "insert success:", len(addManyList)

    finally:
        # close mongo
        conn.close()
        print "close mongo conn"
        if f:
            f.close()
            print "close file"

    print 'cost time:', (time.time() - start)
    pass