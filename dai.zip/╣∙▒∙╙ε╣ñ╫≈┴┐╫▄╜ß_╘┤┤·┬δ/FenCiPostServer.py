import jieba
import tornado.ioloop
import tornado.web

class MainHandler(tornado.web.RequestHandler):
    def post(self):
        word = self.get_arguments('word')
        word = unicode(word[0]).strip()
        word = word.encode("utf-8")
        segList = jieba.cut(word)
        resStr = ""
        for item in segList:
            resStr += item + ","

        self.write(resStr)


application = tornado.web.Application([
    (r"/fc_post", MainHandler)
])

def main():
    application.listen(8098)
    tornado.ioloop.IOLoop.instance().start()
    print "post server start success"

if __name__ == '__main__':
    main()