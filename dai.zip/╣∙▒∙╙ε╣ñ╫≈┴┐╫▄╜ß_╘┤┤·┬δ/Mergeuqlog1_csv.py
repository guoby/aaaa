#encoding=utf-8
import pymongo
import time
import logging
import logging.config
import logging.handlers
import datetime
from xmlrpclib import DateTime
import csv


# 数据保存到的数据库信息
TARGET_IP = "localhost"
TARGET_PORT = 27017
TARGET_DATABASENAME = "faq_handle_data"
TARGET_TABLENAME = "uqestion_merge"
TARGET_TABLENAME_CHANNEL = "uqestion_channel"
TARGET_USER = "qa"
TARGET_PWD = "qa321"

csvFilePath = "E:\\guoby\\work\\1任务\\任务7_20161205\\testdata\\一标一离线模拟.csv"
DATA_TYPE = 1


LOG_FILE = 'e:\\python\\faq.log'  
handler = logging.handlers.RotatingFileHandler(LOG_FILE, maxBytes = 1024*1024, backupCount = 5) # 实例化handler   
fmt = '%(asctime)s - %(filename)s:%(lineno)s - %(levelname)s - %(message)s'  
   
formatter = logging.Formatter(fmt)   # 实例化formatter  
handler.setFormatter(formatter)      # 为handler添加formatter  
   
logger = logging.getLogger('tst')    # 获取名为tst的logger  
logger.addHandler(handler)           # 为logger添加handler  
logger.setLevel(logging.DEBUG)  


def readCsvFile():
    csvFile = open(csvFilePath.decode('utf-8'), "rb") 
    csvdata = csv.reader(csvFile)
    return list(csvdata)


def handleOneData(e):
    
    province = e[0]
    uquestion = e[1]
    squestion = e[2]

    channel = e[4]
    level = 0
    curTime = time.strftime("%Y%m%d",time.localtime(time.time()))
    
    if province.enable("utf-8") in "北京江苏":
        level = 1
    
    element = queryByWhereStr({"uquestion":uquestion,"province":province,"datatype":DATA_TYPE})
    if(len(element) > 0):
        update(uquestion, province, DATA_TYPE, squestion, curTime, level)
        
    else:
        addElement = {}
        addElement.setdefault('province',province)
        addElement.setdefault('uquestion',uquestion)
        addElement.setdefault('squestion',squestion)
        addElement.setdefault("date", curTime)
        addElement.setdefault("level", level)
        addElement.setdefault("keywords", "")
        addElement.setdefault('channel',channel)
        channelItem = queryChannelByWhereStr({"province":province})
        if(len(channelItem) > 0):
            addElement.setdefault('province_code',channelItem[0]['provinceId'])
            insert(addElement)


def handleDate(resList):

    for item in resList[1:]:
        try:
            if(len(item[1]) == 0 or len(item[2]) == 0 or item[1] == "null" or item[2] == "null"):
                print "value is null"
                logger.error("value is null")
                continue
            
            handleOneData(item)
        except Exception, e:  
            logger.error("Exception,:" + str(e))
            print Exception,":",e

def queryByWhereStr(whereStr):
    resultList = []
    conn = pymongo.MongoClient(TARGET_IP, TARGET_PORT)
    db = conn[TARGET_DATABASENAME]
    db.authenticate(TARGET_USER, TARGET_PWD)
    for i in db[TARGET_TABLENAME].find(whereStr):
        resultList.append(i)
    
    return resultList

def queryChannelByWhereStr(whereStr):
    resultList = []
    conn = pymongo.MongoClient(TARGET_IP, TARGET_PORT)
    db = conn[TARGET_DATABASENAME]
    db.authenticate(TARGET_USER, TARGET_PWD)
    for i in db[TARGET_TABLENAME_CHANNEL].find(whereStr):
        resultList.append(i)
    
    return resultList

def insert(element):
    conn = pymongo.MongoClient(TARGET_IP, TARGET_PORT)
    db = conn[TARGET_DATABASENAME]
    db.authenticate(TARGET_USER, TARGET_PWD)
    
    e = {}
    e.setdefault("province", element['province'])
    e.setdefault("uquestion", element['uquestion'])
    e.setdefault("squestion", element['squestion'])
    e.setdefault("channel", element['channel'])
    e.setdefault("province_code", element['province_code'])
    e.setdefault("date", element['date'])
    e.setdefault("level", element['level'])
    e.setdefault("keywords", element['keywords'])
    e.setdefault("datatype", DATA_TYPE)
    #向集合t_handle 添加数据
    db[TARGET_TABLENAME].insert_one(e)
    
    print "insert:-----squestion:" + element['squestion'] + "---------province:" + element['province']
    logger.info("insert:-----squestion:" + element['squestion'] + "---------province:" + element['province'])
    
    
def update(uquestion, province, data_type, squestion, date_time, level):
    conn = pymongo.MongoClient(TARGET_IP, TARGET_PORT)
    db = conn[TARGET_DATABASENAME]
    db.authenticate(TARGET_USER, TARGET_PWD)
    curTime = time.strftime("%Y%m%d",time.localtime(time.time()))
    db[TARGET_TABLENAME].update_one({'uquestion':uquestion,'province':province,"datatype":data_type}, {'$set':{'squestion':squestion,"date":date_time,"level":level}})
    
    print "update:-----squestion:" + squestion + "---------province:" +province
    logger.info("update:-----squestion:" + squestion + "---------province:" +province)

def main():
    resultList = readCsvFile()
    handleDate(resultList)
    
if __name__=="__main__":
    main()