# -*- coding: utf-8 -*-
import json
import time
import sys

errorSignfilePath = 'E:\\guoby\\tj\\tjData\\data\\sign_error_data.txt'
srcfilePath = 'E:\\guoby\\tj\\tjData\\data\\filecache.txt'


def importErrorSignData(fpath = errorSignfilePath):
    delList = []
    filedata = open(fpath,'r')
    for line in filedata.readlines():
        addstr = line.strip().decode('utf-8')
        if len(addstr) > 0:
            delList.append(addstr)
    return delList

def importSrcData(fpath = srcfilePath):
    print "---------- start import 原始数据 ----------"
    resDict = {}
    filedata = open(fpath, 'r')
    for line in filedata.readlines():
        jsonLine = json.loads(line)
        uid = jsonLine.keys()[0]
        for stq in jsonLine.values()[0].keys():
            if resDict.get(stq) == None:
                resDict.setdefault(stq,[uid])
            else:
                resDict[stq].append(uid)
        # print line
    print "---------- end import 原始数据 ----------"
    return resDict

def writeDataToTxt(resDict):
    '''
    向txt写内容
    :param resDict: 内容
    :return:
    '''
    print "---------- start write txt ----------"
    curTime = time.strftime("%Y%m%d%H%M%S", time.localtime(time.time()))
    fname = 'stqData_'+curTime
    print len(resDict)
    try:
        wfile = open(fname + '.txt','a')
        for item in resDict.iteritems():
            stqKey = item[0].encode('utf-8')
            uidCount = str(len(item[1]))
            wfile.write(stqKey +'\t' +uidCount+'\n')
        wfile.close()
    except IOError:
        print ("写入数据出错")
    print "---------- end write txt ----------"
    # 排序
    readData_sort_exportTxt(fname)


def readData_sort_exportTxt(filePath = 'data20170421', sortType=1):
    '''
    从目录读取文件，排序并生成文件
    :param filePath: 读取文件路径
    :param sortType: 排序方式
    :return:
    '''
    print "---------- start sort txt ----------"
    resList = []
    filedata = open(filePath + '.txt', 'r')
    for line in filedata.readlines():
        (stq, num)= line.split('\t')
        n = int(num)
        resList.append((stq, n, len(stq)))
    # sort
    if sortType == 1:
        sortList = sorted(resList, key=lambda i: i[1], reverse=True)# 升序
    elif sortType == 2:
        sortList = sorted(resList, key=lambda i: i[1], reverse=False)# 降序
    elif sortType == 3:
        sortList = sorted(resList, key=lambda i: i[2], reverse=False)

    wfile = open(filePath + '_esc' + '.txt', 'w')
    for slist in sortList:
        sline = slist[0] +'\t'+str(slist[1]) + '\n'
        wfile.write(sline)
    wfile.close()
    print "---------- end sort txt ----------"

def filterSrcData(readfilePath = srcfilePath):
    '''
    过滤出需要删除的内容，其他直接写入文件
    :param readfilePath: 需要过滤内容的文件地址
    :return:
    '''
    print "---------- start 过滤 ----------"
    signList = importErrorSignData()
    similarList = signList[0:8]
    equqlList = signList[8:]

    old_count = 0
    new_count = 0
    # %H%M%S
    curTime = time.strftime("%Y%m%d", time.localtime(time.time()))

    txtList =[]

    filedata = open(readfilePath, 'rb')
    try:
        wfile = open('filecache_' + curTime + '.txt', 'w')
        for line in filedata.readlines():
            old_count = old_count + 1
            # print old_count

            jsonLine = json.loads(line)
            valuesDict = jsonLine.values()[0]

            # 字符完全匹配
            tempList = [v for v in valuesDict.keys() if v in equqlList]
            # 字符包含
            containTempList = [v for v in valuesDict.keys() for vv in similarList if vv in v]
            tempList.extend(containTempList)
            # 去重
            tempList = {}.fromkeys(tempList).keys()

            if len(tempList) > 0:
                for item in tempList: del valuesDict[item]

            if len(valuesDict) > 0:
                new_count = new_count + 1

                writeStr = json.dumps(jsonLine, ensure_ascii=False).encode('utf-8') + '\n'
                wfile.write(writeStr)

            txtList.extend(tempList)

        filedata.close()
        wfile.close()
        print "src_total：" + str(old_count)
        print "new_total：" + str(new_count)
        print "src-new：" + str(old_count-new_count)

        txtList = {}.fromkeys(txtList).keys()
        print 'filter_count: '+str(len(txtList))

    except IOError:
        print ("写入数据出错")
    print "---------- end 过滤 ----------"


if __name__ == '__main__':
    '''
    测试方式：
    1、先执行筛选方法
    2、再验证
    '''
    print "开始执行... ..."

    # 筛选
    filterSrcData()

    # 验证
    # resDict = importSrcData('filecache_20170424.txt')
    # writeDataToTxt(resDict)



