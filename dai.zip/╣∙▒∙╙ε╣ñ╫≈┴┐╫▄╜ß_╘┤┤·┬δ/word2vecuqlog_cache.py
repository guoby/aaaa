#encoding=utf-8
'''
Created on 2017��3��24��

@author: cmri
'''
import logging
import logging.config
import logging.handlers

import json
from gensim.models.word2vec import *


LOG_FILE = 'C:\\data\\data\\log\\uqlog.log'
LOG_FILE = 'd:\\python\\faq.log'

handler = logging.handlers.RotatingFileHandler(LOG_FILE, maxBytes = 1024*1024, backupCount = 5) # 实例化handler   
fmt = '%(asctime)s - %(filename)s:%(lineno)s - %(levelname)s - %(message)s'  
   
formatter = logging.Formatter(fmt)   # 实例化formatter  
handler.setFormatter(formatter)      # 为handler添加formatter  
   
logger = logging.getLogger('tst')    # 获取名为tst的logger  
logger.addHandler(handler)           # 为logger添加handler  
logger.setLevel(logging.DEBUG)  

model_file = 'word2vec.model'

# with open('C:\\data\\data\\uqlog0330.txt') as f:
#     prefs_str = ''.join(f.readlines())



def getFilelist(argv) :
    path = argv

    filelist = []
    files = os.listdir(argv)
    for f in files :
        if(f[0] == '.') :
            pass
        else :
            filelist.append(f)
    return filelist,path



# {'andy': {'霍乱时期的爱情': 1,'霍乱时期的爱情':1},...}
def read_prefs(prefs_str):
    prefs = {}
    print len(prefs_str.split('\n'))
    for line in prefs_str.split('\n'):
        # print line
        parts = line.rstrip().split('\t')
        if len(parts) == 2:
            userId, itemId = parts

            if prefs.get(userId) != None:
                prefs[userId].update({itemId:1})
            else:
                if prefs != {}:
                    # prefs 写入文档
                    print userId
                    writeDataToTxt(prefs)
                    prefs.clear()
                    prefs = {}

                prefs.setdefault(userId,{itemId:1})
    writeDataToTxt(prefs)


def writeDataToTxt(prefs):
    logger.info("start write data... ...:")
    try:
        wfile = open('ttt3.txt','a')
        wfile.write(json.dumps(prefs,ensure_ascii=False)+'\n')
        wfile.close()
        # print "write data sucess... ..."
    except IOError:
        logger.info("写入数据出错")


def sents_from_prefs(prefsFilePath):

    sents = []
    # //遍历文本的每一行
    prefs = open(prefsFilePath, 'r')
    for v in prefs.readlines():
        vdict = json.loads(v)
        vdictSize = len(vdict.values()[0])
        if vdictSize < 4 or vdictSize > 10:
            continue

        sent = ' '.join(vdict.values()[0].keys())
        print sent
        sents.append(sent)
    return sents

def flatMap(vocab):
    ret = []
    for i in vocab:
        if type(i) == type('a'):
            ret.append(i)
        elif type(i) == type([]):
            for j in i:
                ret.append(j)
    return ret

def calc_item_cf(ps):
    sents = sents_from_prefs(ps)
    vocab = [s.split() for s in sents]
    model = Word2Vec(vocab, size=100, window=4, min_count=2, workers=4)
    #min_count: 可以对字典做截断. 词频少于min_count次数的单词会被丢弃掉, 默认值为5
    #window：表示当前词与预测词在一个句子中的最大距离是多少
    model.save_word2vec_format(model_file, binary=False)
    model = Word2Vec.load_word2vec_format(model_file, binary=False)
    logger.info("开始：")
    for item in flatMap(vocab):
        item= item.encode('utf-8')
        print('\n根据 %s 推荐：' % item)

        logger.info('\n根据 %s 推荐：' % item)
        try:
            for item_score in model.most_similar(positive=[item.decode('utf-8')]):
                item, score = item_score
                print('\t%s %.2f' % (item, score))
                logger.info('\t%s %.2f' % (item, score))
        except:
            logger.info("词向量中无此key:"+item.encode('utf-8'))
#     y2 = model.most_similar("查询流量".decode("utf-8"), topn=5)  # 20个最相关的
#     for item in y2:
#         print item[0], item[1]
if __name__ == "__main__" :
    (allfile,path) = getFilelist("E:\\guoby\\tj\\tjData\\testdata\\20170419data\\")
    print path
    prefs_str=''
    for ff in allfile:
        f=open(path+ff,'r+')
        prefs_str+=''.join(f.readlines())+'\n'

    prefs = read_prefs(prefs_str)
    calc_item_cf('ttt3.txt')
    # sents = sents_from_prefs('ttt3.txt')