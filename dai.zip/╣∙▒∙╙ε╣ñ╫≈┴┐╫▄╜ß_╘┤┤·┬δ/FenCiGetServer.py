# -*- coding: utf-8 -*-
import json
import urllib2

import demjson
import jieba
import tornado.ioloop
import tornado.web


class MainHandler(tornado.web.RequestHandler):
    def get(self):
        word = self.get_arguments('word')
        word = unicode(word[0]).strip()
        word = word.encode("utf-8")
        # 对字符串进行解码
        word = urllib2.unquote(word)
        segList = jieba.cut(word)

        resList = []
        for item in segList:
            # item = item.encode("utf-8")
            resList.append(item)

        encodedjson = json.dumps(resList)
        resultJosn = {'list':resList}
        print resultJosn
        self.write(resultJosn)

    # def get(self):
    #     word = self.get_arguments('word')
    #     print word
    #
    #     word = unicode(word[0]).strip()
    #     word = word.encode("utf-8")
    #     # 对字符串进行解码
    #     word = urllib2.unquote(word)
    #     segList = jieba.cut(word)
    #     resStr = ",".join(segList)
    #     # 输出结果
    #     self.write(resStr)

application = tornado.web.Application([
    (r"/fc", MainHandler)
])

def main():
    application.listen(8099)
    tornado.ioloop.IOLoop.instance().start()
    print "get server start success"

if __name__ == '__main__':
    main()