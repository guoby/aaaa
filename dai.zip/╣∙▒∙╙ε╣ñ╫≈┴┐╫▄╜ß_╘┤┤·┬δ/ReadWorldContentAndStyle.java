package com.cmri.kb.thread;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.UnsupportedEncodingException;

import org.apache.log4j.Logger;
import org.apache.poi.hwpf.HWPFDocument;
import org.apache.poi.hwpf.model.PicturesTable;
import org.apache.poi.hwpf.usermodel.CharacterRun;
import org.apache.poi.hwpf.usermodel.Paragraph;
import org.apache.poi.hwpf.usermodel.Picture;
import org.apache.poi.hwpf.usermodel.Range;
import org.apache.poi.hwpf.usermodel.Table;
import org.apache.poi.hwpf.usermodel.TableCell;
import org.apache.poi.hwpf.usermodel.TableIterator;
import org.apache.poi.hwpf.usermodel.TableRow;
import org.apache.poi.xwpf.converter.core.FileImageExtractor;
import org.apache.poi.xwpf.converter.core.FileURIResolver;
import org.apache.poi.xwpf.converter.xhtml.XHTMLConverter;
import org.apache.poi.xwpf.converter.xhtml.XHTMLOptions;
import org.apache.poi.xwpf.usermodel.XWPFDocument;

/***
 * 
 * @Title: ReadWorldContentAndStyle.java
 * @Package com.cmri.kb.thread
 * @author guoby
 * @date 2016年12月2日
 */
public class ReadWorldContentAndStyle {
	
	private static Logger log = Logger.getLogger(ReadWorldContentAndStyle.class);
	
	/** 
     * 回车符ASCII码 
     */  
    private static final short ENTER_ASCII = 13;  
  
    /** 
     * 空格符ASCII码 
     */  
    private static final short SPACE_ASCII = 32;  
  
    /** 
     * 水平制表符ASCII码 
     */  
    private static final short TABULATION_ASCII = 9;   
    
	public static String htmlText = "";  
	public static String htmlTextTbl = "";  
    public static int counter=0;  
    public static int beginPosi=0;  
    public static int endPosi=0;  
    public static int beginArray[];  
    public static int endArray[];  
    public static String htmlTextArray[];  
    public static boolean tblExist=false;
    
    
    public static void main(String[] args) {
    	String inputFile = "E:\\guoby\\work\\1task\\task_20161118\\data\\商旅100\\差旅相关\\安徽.docx";
		try {  
            
			readWorldAndStyle(inputFile, "E:\\20161202test\\images\\");
        } catch (Exception e) {  
            e.printStackTrace();  
        }   
		
		
	}
    
    /***
     * 读取world 内容和基本格式
     * 
     * @param path
     * @param imgPath
     * @return
     */
    public static String readWorldAndStyle(String path, String imgPath){
    	
    	String resultStr = "";
    	String suffix = path.substring(path.lastIndexOf(".") + 1);
		try {
			if (suffix.equals("doc")) {
				
				resultStr = getWord2003AndStyle(path, imgPath);
				 
			} else if (suffix.equals("docx")) {
				resultStr = getWord2007AndStyle(path, imgPath);
			}
		} catch (Exception e) {
			log.error("读取world报错：" + e);
			e.printStackTrace();
		}
		return resultStr;
    }
    
    /** 
     * 读取每个文字样式 
     *  
     * @param fileName 
     * @throws Exception 
     */  
	private static String getWord2003AndStyle(String fileName, String imgPath) throws Exception {
		
		FileInputStream in = new FileInputStream(new File(fileName));
		HWPFDocument doc = new HWPFDocument(in);
		Range rangetbl = doc.getRange();// 得到文档的读取范围

		TableIterator it = new TableIterator(rangetbl);
		int num = 100;

		beginArray = new int[num];
		endArray = new int[num];
		htmlTextArray = new String[num];

		// 取得文档中字符的总数
		int length = doc.characterLength();
		// 创建图片容器
		PicturesTable pTable = doc.getPicturesTable();

		htmlText = "<html><head><title>"
				+ doc.getSummaryInformation().getTitle()
				+ "</title></head><body>";
		// 创建临时字符串,好加以判断一串字符是否存在相同格式
		if (it.hasNext()) {
			readTable(it, rangetbl);
		}

		int cur = 0;

		String tempString = "";
		for (int i = 0; i < length - 1; i++) {
			// 整篇文章的字符通过一个个字符的来判断,range为得到文档的范围
			Range range = new Range(i, i + 1, doc);

			CharacterRun cr = range.getCharacterRun(0);
			// beginArray=new int[num];
			// endArray=new int[num];
			// htmlTextArray=new String[num];
			if (tblExist) {
				if (i == beginArray[cur]) {
					htmlText += tempString + htmlTextArray[cur];
					tempString = "";
					i = endArray[cur] - 1;
					cur++;
					continue;
				}
			}
			if (pTable.hasPicture(cr)) {
				htmlText += tempString;
				// 读写图片
				readPicture(pTable, cr, imgPath);
				tempString = "";
			} else {

				Range range2 = new Range(i + 1, i + 2, doc);
				// 第二个字符
				CharacterRun cr2 = range2.getCharacterRun(0);
				char c = cr.text().charAt(0);

//				System.out.println(i + "::" + range.getEndOffset() + "::" + range.getStartOffset() + "::" + c);

				// 判断是否为回车符
				if (c == ENTER_ASCII) {
					tempString += "<br/>";
				}
				// 判断是否为空格符
				else if (c == SPACE_ASCII)
					tempString += " ";
				// 判断是否为水平制表符
				else if (c == TABULATION_ASCII)
					tempString += "    ";
				// 比较前后2个字符是否具有相同的格式
				boolean flag = compareCharStyle(cr, cr2);
				if (flag)
					tempString += cr.text();
				else {
					String fontStyle = "<span style=\"font-family:"
							+ cr.getFontName() + ";font-size:"
							+ cr.getFontSize() / 2 + "pt;";

					if (cr.isBold())
						fontStyle += "font-weight:bold;";
					if (cr.isItalic())
						fontStyle += "font-style:italic;";
					fontStyle += "\"";

					htmlText += fontStyle + " mce_style=\"font-family:"
							+ cr.getFontName() + ";font-size:"
							+ cr.getFontSize() / 2 + "pt;";

					if (cr.isBold())
						fontStyle += "font-weight:bold;";
					if (cr.isItalic())
						fontStyle += "font-style:italic;";
					fontStyle += "\"";

					htmlText += fontStyle + ">" + tempString + cr.text()
							+ "</span>";
					tempString = "";
				}
			}
		}

		htmlText += tempString + "</body></html>";
//		writeFile(htmlText);
		
		return htmlText;
	}   
    
	
    /** 
     * 读写文档中的表格 
     *  
     * @param pTable 
     * @param cr 
     * @throws Exception 
     */  
	private static void readTable(TableIterator it, Range rangetbl)
			throws Exception {

		htmlTextTbl = "";
		// 迭代文档中的表格

		counter = -1;
		while (it.hasNext()) {
			tblExist = true;
			htmlTextTbl = "";
			Table tb = (Table) it.next();
			beginPosi = tb.getStartOffset();
			endPosi = tb.getEndOffset();

//			System.out.println("............" + beginPosi + "...." + endPosi);
			counter = counter + 1;
			// 迭代行，默认从0开始
			beginArray[counter] = beginPosi;
			endArray[counter] = endPosi;

			htmlTextTbl += "<table cellspacing=\"0\" cellpadding=\"5\" border>";
			for (int i = 0; i < tb.numRows(); i++) {
				TableRow tr = tb.getRow(i);

				htmlTextTbl += "<tr>";
				// 迭代列，默认从0开始
				for (int j = 0; j < tr.numCells(); j++) {
					TableCell td = tr.getCell(j);// 取得单元格
					int cellWidth = td.getWidth();

					// 取得单元格的内容
					for (int k = 0; k < td.numParagraphs(); k++) {
						Paragraph para = td.getParagraph(k);
						String s = para.text().toString().trim();
						if (s == "") {
							s = " ";
						}
//						System.out.println(s);
						htmlTextTbl += "<td width=" + cellWidth + ">" + s
								+ "</td>";
//						System.out.println(i + ":" + j + ":" + cellWidth + ":"
//								+ s);
					} // end for
				} // end for
			} // end for
			htmlTextTbl += "</table>";
			htmlTextArray[counter] = htmlTextTbl;

		} // end while
	}    
	
    /** 
     * 读写文档中的图片 
     *  
     * @param pTable 
     * @param cr 
     * @throws Exception 
     */  
    private static void readPicture(PicturesTable pTable, CharacterRun cr, String imgPath) throws Exception {  
        // 提取图片   
        Picture pic = pTable.extractPicture(cr, false);  
        // 返回POI建议的图片文件名   
        String afileName = pic.suggestFullFileName();  
        
//        String imgPath = "temp/world/image";
        File file = new File(imgPath);
        file.mkdirs();
//        file = new File(path + File.separator + "a.txt");
//		file.createNewFile();
        
        OutputStream out = new FileOutputStream(new File(imgPath + File.separator + afileName));  
        pic.writeImageContent(out);  
        htmlText += "<img src='" + imgPath + afileName + "/>";   
    }  
  
    private static boolean compareCharStyle(CharacterRun cr1, CharacterRun cr2)   
    {  
        boolean flag = false;  
        if (cr1.isBold() == cr2.isBold() && cr1.isItalic() == cr2.isItalic() && cr1.getFontName().equals(cr2.getFontName()) && cr1.getFontSize() == cr2.getFontSize())   
        {  
            flag = true;  
        }  
        return flag;  
    }   
    
//    /** 
//     * 写文件 
//     *  
//     * @param s 
//     */  
//	private static void writeFile(String s) {
//		FileOutputStream fos = null;
//		BufferedWriter bw = null;
//		try {
//			File file = new File("e://abc.html");
//			fos = new FileOutputStream(file);
//			bw = new BufferedWriter(new OutputStreamWriter(fos, "utf-8"));
//
//			bw.write(s);
//		} catch (FileNotFoundException fnfe) {
//			fnfe.printStackTrace();
//		} catch (IOException ioe) {
//			ioe.printStackTrace();
//		} finally {
//			try {
//				if (bw != null)
//					bw.close();
//				if (fos != null)
//					fos.close();
//			} catch (IOException ie) {
//			}
//		}
//	}
	
	/********************************world 2007****************************************/
	private static String getWord2007AndStyle(String docxPath, String tempFolder) throws IOException {
		long startTime = System.currentTimeMillis();
		String fileInName = "test" + startTime;
//		String docxPath = "E:\\guoby\\work\\1task\\task_20161118\\data\\商旅100\\差旅相关\\安徽.docx";
//		String tempFolder = "E:\\20161202test\\images\\";
		String fileOutPath = tempFolder + fileInName + ".html";


		XWPFDocument document = new XWPFDocument(new FileInputStream(docxPath));
		XHTMLOptions options = XHTMLOptions.create().indent(4);
		// Extract image
		File imageFolder = new File(tempFolder);
		options.setExtractor(new FileImageExtractor(imageFolder));
		// URI resolver
		options.URIResolver(new FileURIResolver(imageFolder));

		File outFile = new File(fileOutPath);
		outFile.getParentFile().mkdirs();
		OutputStream out = new FileOutputStream(outFile);
		XHTMLConverter.getInstance().convert(document, out, options);

//		System.out.println("Generate " + fileOutPath + " with " + (System.currentTimeMillis() - startTime) + " ms.");
		
		String content = streamToString(new FileInputStream(fileOutPath), "utf-8");
		System.out.println("read world 2007 success");
		return content;
	}

	/**
	 * File2String
	 * 
	 * @param in
	 * @param charset
	 * @return String
	 */
	private static String streamToString(InputStream in, String charset) {
		StringBuffer sb = new StringBuffer();
		try {
			Reader r = new InputStreamReader(in, charset);
			int length = 0;
			for (char[] c = new char[1024]; (length = r.read(c)) != -1;) {
				sb.append(c, 0, length);
			}
			r.close();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return sb.toString();
	}
	

}
