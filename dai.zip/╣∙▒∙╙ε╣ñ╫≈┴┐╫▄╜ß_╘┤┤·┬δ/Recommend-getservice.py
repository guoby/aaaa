# -*- coding: utf-8 -*-
import urllib2

import jieba
import tornado.ioloop
import tornado.web


class MainHandler(tornado.web.RequestHandler):
    def get(self):
        query = self.get_arguments('q')
        channel=self.get_arguments('c')
        province=self.get_arguments('l')
        #查询语句
        query = unicode(query[0]).strip()
        query = query.encode("utf-8")
        #渠道
        channel = unicode(channel[0]).strip()
        channel = channel.encode("utf-8")
        #省份
        province=unicode(province[0]).strip()
        province = province.encode("utf-8")

        print query
        print channel
        print province

        #get服务传参要先编码
        query = urllib2.quote(query)
        channel=urllib2.quote(channel)
        province=urllib2.quote(province)
        
    # #第一步 基于搜索完成初筛
    #     #先调用同义词服务
    #     syn_url = "http://"%query
    #     res_syn = urllib2.urlopen(syn_url)
    #     querySyn = res_syn.read()
    #     #调用业务分类服务（在原始query基础上）这个暂时不用 等燕蒙
    #     bustp_url = "http://**/**?word=%s"%query
    #     res_bustp = urllib2.urlopen(bustp_url)
    #     bus_tp = res_bustp.read()
    #
    #     #搜索 原始query和同义词替换的query同时搜索，取最高；业务分类结果作为filter。直接调用索引服务
    #     index_url = "http://"%(query,querySyn,bus_tp,channel,province)
    #     res_index = urllib2.urlopen(index_url)
    #     resIndex = res_index.read()
    #
    # #第二步 搜索的结果前两条 基于word2vec模型进行相关性查找
    #     model = Word2Vec.load_word2vec_format(model_file, binary=False)
    #     y2 = model.most_similar(resIndex(0).decode("utf-8"), topn=3)  # 3个最相关的


application = tornado.web.Application([
    (r"/fc", MainHandler)
])

def main():
    application.listen(8099)
    tornado.ioloop.IOLoop.instance().start()
    print "get server start success"

if __name__ == '__main__':
    main()