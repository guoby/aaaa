# -*- coding: utf-8 -*-
import json
import urllib
import urllib2

import demjson


def testGet2(query, channel, province):
    print "发起 get 请求测试"
    # 对字符串进行编码
    query = urllib2.quote(query)
    channel = urllib2.quote(channel)
    province = urllib2.quote(province)
    url = "http://localhost:8099/fc?q=%s&c=%s&l=%s"%(query, channel, province)
    res_data = urllib2.urlopen(url)
    resStr = res_data.read()
    print resStr

def testGet(word):
    print "发起 get 请求测试... ...."
    # 对字符串进行编码
    word = urllib2.quote(word)
    url = "http://localhost:8099/fc?word=%s"%word
    res_data = urllib2.urlopen(url)
    resStr = res_data.read()
    print type(resStr)
    # resjson = json.loads(resStr)
    # for i in list(resStr):
    #     print i.encode('utf-8')

    print resStr


def testPost(word):
    print "发起 post 请求测试... ..."
    url = "http://localhost:8098/fc_post"
    params = {'word': word}
    data = urllib.urlencode(params)
    req = urllib2.Request(url=url, data=data)
    res_data = urllib2.urlopen(req)
    resStr = res_data.read()
    print resStr

if __name__ == '__main__':
    str = '电视剧人民的名义get'
    # testGet2(str, '0123 01 21', '北京')
    # testPost(str)
    # testGet(str)

    # segList = [1,2,3]
    # encodedjson = json.dumps(segList)
    # print repr(encodedjson)

    # content = '你好'
    # # content = content.encode('utf-8')
    # content = urllib2.quote(content)

    # print content
    # content = urllib2.unquote(content)
    # print content